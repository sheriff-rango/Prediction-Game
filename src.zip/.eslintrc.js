/** @type {import('eslint').Linter.Config} */
module.exports = {
  extends: ["plugin:react/jsx-runtime"],
};
