export const BackendUrl = "http://localhost:5000"
