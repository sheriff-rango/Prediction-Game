export const OracleContract =
    "sei1rzjtyu2hvw430d4zee0cjs2wjurkprage2r2ly9w8t3u0exlsfls8ny7sy"

export const FuzioContract =
    "sei17thak4mluh3v98ek7yv64rul9zecpaqpdhr3szgspxdvzk22dyxsrahms8"

export const FuzioOptionContract =
    "sei1ej8640aa98umk0yc96dnkzzuvxw98kst5z4yjfcnfmxlvjuzmatsjlfgx9"
