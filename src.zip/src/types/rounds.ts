export type TRounds = "expired" | "live" | "next" | "later" | "calculating"
