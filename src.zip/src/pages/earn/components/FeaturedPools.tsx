export const FeaturedPools = () => {
  return
}
