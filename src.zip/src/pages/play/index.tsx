import Prediction from "./Prediction"

export { Prediction }
