import { getModal } from "./getModal"

export const DefaultModal = getModal()
