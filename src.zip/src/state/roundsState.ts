import { atom } from "recoil"

export const roundsState = atom<
    {
        id: number
        status: "expired" | "live" | "next" | "later" | "calculating"
        bid_time: number
        open_time: number
        close_time: number
        bull_amount: number
        bear_amount: number
        current_time: number
    }[]
>({
    default: [],
    key: "roundsState"
})
